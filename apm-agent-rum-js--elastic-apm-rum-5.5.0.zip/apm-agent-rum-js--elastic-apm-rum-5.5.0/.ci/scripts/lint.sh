#!/usr/bin/env bash
npm install
npm run lint
scripts/lint-commits.sh
