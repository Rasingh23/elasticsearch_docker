<template>
  <div>
    <h2>Lazy loaded component</h2>
  </div>
</template>